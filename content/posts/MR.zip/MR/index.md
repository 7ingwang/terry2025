---
title: "MR眼镜与电子沙盘3D演示"
date: 2024-10-28T16:00:00-05:00
draft: false
author: "Terry"
categories: ["3D"]
tags: ["3D", "blender"]
featured_image: "mr.png"
---
![3D](mr.png)